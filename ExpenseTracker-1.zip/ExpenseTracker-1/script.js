const form = document.getElementById("expense-form");
const expenseList = document.getElementById("expense-list");
const balanceDisplay = document.getElementById("balance");

let totalBalance = 0;

form.addEventListener("submit", function (e) {
  e.preventDefault();

  const title = document.getElementById("title").value;
  const amount = parseFloat(document.getElementById("amount").value);
  const date = document.getElementById("date").value;

  if (title && amount && date) {
    addExpense(title, amount, date);
    updateBalance(amount);
    form.reset();
  }
});

function addExpense(title, amount, date) {
  const li = document.createElement("li");
  li.classList.add("expense-item");

  li.innerHTML = `
    <div class="expense-info">
      <strong>${title}</strong><br>
      ₹${amount.toFixed(2)} <small>(${date})</small>
    </div>
    <button class="delete-btn">X</button>
  `;

  li.querySelector(".delete-btn").addEventListener("click", () => {
    li.remove();
    updateBalance(-amount);
  });

  expenseList.appendChild(li);
}

function updateBalance(change) {
  totalBalance += change;
  balanceDisplay.textContent = `Total: ₹${totalBalance.toFixed(2)}`;
}
